<template>
  <div id="app">
    <router-view>
      <home></home>
    </router-view>
  </div>
</template>

<script>
  import Home from "../src/views/home/Home";

  export default {
    name: 'App',
    components: {
      Home
    }
  }
</script>

<style>
  @import "./assets/css/base.css";
</style>
