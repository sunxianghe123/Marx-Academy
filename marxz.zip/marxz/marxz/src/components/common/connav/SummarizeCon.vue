<template>
  <div class="summarize-con">

  </div>
</template>

<script>
export default {
  name: "SummarizeCon"
}
</script>

<style scoped>
.summarize-con {
  width: 887px;
  height: 642px;
  background: #FFFFFF;
  display: flex;
  flex-direction: column;
  color: #000000;
}

</style>